<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$file = 'data.json';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $profession = isset($_POST['profession']) ? trim($_POST['profession']) : '';
    $password = isset($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : '';

    if (!empty($name) && !empty($profession) && !empty($password)) {
        $data = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
        $data[] = ["name" => $name, "profession" => $profession, "password" => $password];
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));

        echo json_encode(["message" => "Cadastro realizado com sucesso!"]);
    } else {
        echo json_encode(["message" => "Preencha todos os campos!"]);
    }
} elseif ($_SERVER["REQUEST_METHOD"] === "GET") {
    $data = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
    $filteredData = array_map(function ($user) {
        return ["name" => $user["name"], "profession" => $user["profession"]];
    }, $data);
    echo json_encode($filteredData);
} else {
    echo json_encode(["message" => "Método não permitido!"]);
}
?>
